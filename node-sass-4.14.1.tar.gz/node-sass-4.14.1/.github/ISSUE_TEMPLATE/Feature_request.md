---
name: Feature request
about: Suggest an idea for this project

---

<!--

Before you request a feature, please realize this project is a wrapper for
LibSass so we can't add any language features here. If you want to add a feature
to the Sass language, please open an issue on https://github.com/sass/sass/issues/new

If you want a CLI feature, please make sure that it is supported by https://github.com/sass/sass

Thanks for making node-sass better!

-->
